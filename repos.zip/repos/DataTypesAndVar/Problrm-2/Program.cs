﻿double distance = double.Parse(Console.ReadLine());
double time = double.Parse(Console.ReadLine());

double speed = distance / time;

Console.WriteLine($"{speed:F2}");



