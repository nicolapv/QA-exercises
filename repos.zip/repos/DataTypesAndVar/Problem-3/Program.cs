﻿double radius =double.Parse(Console.ReadLine());

double area = radius * radius * Math.PI;
double permimeter = 2 * radius * Math.PI;

Console.WriteLine($"Area = {area:F2}");
Console.WriteLine($"Perimeter = {permimeter:F2}");