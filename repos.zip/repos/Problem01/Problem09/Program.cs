﻿string movieType = Console.ReadLine();
int rows = int.Parse(Console.ReadLine());
int seats = int.Parse(Console.ReadLine());

double totalAmount = 0;
double ticketPrice = 0;

if (movieType == "Normal")
{
    ticketPrice = 7.50;
}
else if (movieType == "Premiere")
{
    ticketPrice = 12.00;
}
else if (movieType == "Discount")
{
    ticketPrice = 5.00;
}
totalAmount = rows * seats * ticketPrice;
Console.WriteLine($"{totalAmount:F2}");