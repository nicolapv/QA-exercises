﻿int dayOfWeeek = int.Parse(Console.ReadLine());

if (dayOfWeeek == 1 )
{
    Console.WriteLine("Monday");
}
else if (dayOfWeeek == 2)
{
    Console.WriteLine("Tuesdasy");
}
else if(dayOfWeeek == 3)
{
    Console.WriteLine("Wednesday");
}
else if(dayOfWeeek == 4)
{
    Console.WriteLine("Thursday");
}
else if (dayOfWeeek == 5)
{
    Console.WriteLine("Friday");
}
else if (dayOfWeeek == 6)
{
    Console.WriteLine("Saturday");
}
else if (dayOfWeeek == 7)
{
    Console.WriteLine("Sunday");
}
else
{
    Console.WriteLine("Error");
}