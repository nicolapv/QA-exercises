﻿int num = int.Parse(Console.ReadLine());

bool isNumberValid = (num >= 100 && num <= 200) || num == 0;

if (!isNumberValid)
{
    Console.WriteLine("invalid");
}
