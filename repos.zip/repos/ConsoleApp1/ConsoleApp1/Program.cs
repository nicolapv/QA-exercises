﻿int aquariumLenghtCm = int.Parse(Console.ReadLine());
int aquariumWidthCm = int.Parse(Console.ReadLine());
int aquariumHeightCm = int.Parse(Console.ReadLine());
double occupiedSpace = double.Parse(Console.ReadLine());

double aquariumVolumeCm = aquariumLenghtCm * aquariumWidthCm * aquariumHeightCm;
double aquariumVolumeLiters = aquariumVolumeCm * 0.001;
double occupiedSpacePercentage = occupiedSpace * 0.01;

double requiredLiters = aquariumVolumeLiters * (1 - occupiedSpacePercentage);

Console.WriteLine($"{requiredLiters:F2}");